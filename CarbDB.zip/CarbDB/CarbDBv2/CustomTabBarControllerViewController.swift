//
//  CustomTabBarControllerViewController.swift
//  CarbDBv2
//
//  Created by Tammy McCullough on 5/6/20.
//  Copyright © 2020 Reid VanDiepen. All rights reserved.
//

import UIKit

//WIP

class CustomTabBarControllerViewController: UITabBarController, UITabBarControllerDelegate {

    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    var editedFoods: [Food] = []
    
    
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
